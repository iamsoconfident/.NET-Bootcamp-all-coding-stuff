﻿namespace CSharp.Activity.Delegates
{
    public class LoanApplicant
    {
        public double CreditScore { get; set; }
    }
}
