﻿namespace CSharp.Activity.Polymorphism
{
    internal interface IPrintable
    {
        public void Print();
    }
}
